package com.java8.lambda.expression;

public class LETest {
	public static void main(String[] args) {
		
		/*InterFaceTest i = (int a,int b)-> { return a+b;};
		System.out.println(i.getText(10,20));
		
		InterFaceTest1 i1 = (int a)->  System.out.println(a);
		i1.getText(10);
		
		InterFaceTest2 i2 = ()->  System.out.println("Galaxy Weblinks");
		i2.printText();*/
		
		InterFaceTest2 i2 =   ()->  System.out.println("Galaxy Weblinks");
		
		InterFaceTest1 i1 =   (int a)->  System.out.println(a);
		
		InterFaceTest i =    (int a,int b)-> { return a+b;};
		
		
		
		
	}
}
interface InterFaceTest{
	int getText(int a,int b);
}

interface InterFaceTest1{
	void getText(int suffix);
}

interface InterFaceTest2{
	void printText();
}
package com.java8.lambda.expression;

public class LambdaExpressionExample {

	public static void main(String args[]) {
		InterFaceDemo1 loan=(int a,int b)->{System.out.println(a+b);};
		loan.addNumber(10, 20);
	}
}

interface InterFaceDemo1{
	void addNumber(int a,int b);
}
package com.java8.lambda.expression;

public class LambdaExpression {

	public void displayName(){
		System.out.println("Mayank Jain");
	}
	
	()->{
		System.out.println("Mayank Jain");
	};


}

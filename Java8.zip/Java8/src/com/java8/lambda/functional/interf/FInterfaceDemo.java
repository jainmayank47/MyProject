package com.java8.lambda.functional.interf;

@FunctionalInterface
public interface FInterfaceDemo {

	public void printText();
	
	
}

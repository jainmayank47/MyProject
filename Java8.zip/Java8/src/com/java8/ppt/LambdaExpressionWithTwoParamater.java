package com.java8.ppt;

public class LambdaExpressionWithTwoParamater {

	public static void main(String[] args) {
		TwoParameterInterface two = (String str, String str1) -> {
			return str.concat(str1);
		};
		System.out.println(two.printText("Mayank ","Jain"));
	}

}
interface TwoParameterInterface{
	public String printText(String str,String str1);
}
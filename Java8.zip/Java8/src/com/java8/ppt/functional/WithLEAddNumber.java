package com.java8.ppt.functional;

public class WithLEAddNumber {

	public static void main(String args[]) {
		InterFaceDemo11 interFaceDemo1=(int a,int b)->{System.out.println(a+b);};
		interFaceDemo1.addNumber(10, 20);
	}
}
@FunctionalInterface
interface InterFaceDemo11{
	void addNumber(int a,int b);
}

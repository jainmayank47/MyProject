package com.java8.ppt.functional;

public class Act_As_A_Type_Parameter {

	public static void main(String[] args) {
		String name = "mayank jain";
		int count =10;
		InterfaceDemo5 interf = (a,b)->System.out.println(a+b);
		interf.addNumber(10, 20);

	}

}
interface InterfaceDemo5{
	public void addNumber(int a,int b);
}
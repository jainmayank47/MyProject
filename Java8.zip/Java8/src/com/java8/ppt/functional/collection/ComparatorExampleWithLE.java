package com.java8.ppt.functional.collection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ComparatorExampleWithLE {
	public static void main(String[] args) {
		List<Employee> empList = new ArrayList<>();
		empList.add(new Employee(104, "Zakir"));
		empList.add(new Employee(101, "Naveen"));
		empList.add(new Employee(103, "Aamir"));
		empList.add(new Employee(102, "Viplove"));
		empList.add(new Employee(105, "Ritik"));
		System.out.println("Before Sorting List Using Lambda Expression");
		System.out.println(empList.toString());
		System.out.println("\n After Sorting List By Name Using Lambda Expression");
		// using Lambda Expression no need to create separate class for comparator.
		Collections.sort(empList, (e1,e2)->e1.getEmpName().compareTo(e2.getEmpName()));
		System.out.println(empList.toString());
	}
}

package com.java8.ppt.functional.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ComparatorExampleWithoutLE {

	public static void main(String[] args) {
		List<Employee> empList = new ArrayList<>();
		empList.add(new Employee(104, "Zakir"));
		empList.add(new Employee(101, "Naveen"));
		empList.add(new Employee(103, "Aamir"));
		empList.add(new Employee(102, "Viplove"));
		empList.add(new Employee(105, "Ritik"));
		
		System.out.println("Before Sorting List");
		System.out.println(empList.toString());
		
		System.out.println("After Sorting List By Name");
		Collections.sort(empList, new MyEmployeeComparator());
		System.out.println(empList.toString());

	}

}

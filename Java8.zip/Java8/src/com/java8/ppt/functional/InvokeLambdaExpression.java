package com.java8.ppt.functional;

public class InvokeLambdaExpression {

	public static void main(String[] args) {
		Loan loan = (a,b)->(a*b*8)/100;
		System.out.println("Loan Interest: "+loan.calculateLoanIntrest(10, 20));

	}

}
interface Loan{
	public int calculateLoanIntrest(int a,int b);
}
package com.java8.ppt.functional;

import java.util.ArrayList;

public interface StaticAndDefaultMethods {

	public int getStudentId(String studentName);
	default String getStudentName(){
		return "Mayank jain";
	}
	default void displayStudentMarks(){
		System.out.println("74%");
	}
	static ArrayList<String> getStudentList(){
		ArrayList<String> studentList = new ArrayList<>();
		studentList.add("mayank");
		studentList.add("deepak");
		studentList.add("arun");
		return studentList;
	}
}

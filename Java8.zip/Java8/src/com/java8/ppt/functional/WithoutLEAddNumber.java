package com.java8.ppt.functional;

import com.java8.lambda.expression.WithoutLambdaExpression;

public class WithoutLEAddNumber implements InterfaceDemo {

	public static void main(String[] args) {
		WithoutLambdaExpression wle = new WithoutLambdaExpression();
		wle.addNumber(10, 20);
	}
	@Override
	public void addNumber(int a, int b) {
		System.out.println(a+b);
	}
}
interface InterfaceDemo{
	void addNumber(int a,int b);

}

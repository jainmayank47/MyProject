package com.java8.ppt.functional;

@FunctionalInterface
public interface ExactlyOneMethod {

	public int getEmployeeId();
	
	//public String getEmployeeName();
}

package com.java8.ppt;

public class LambdaExpressionZeroNoParamater {
	public static void main(String[] args) {
		ZeroNoInterface zero=()->{System.out.println("Hello World");};
		zero.printText();
	}
}

interface ZeroNoInterface{
	public void printText();
}
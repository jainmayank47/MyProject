package com.java8.ppt;

public class LambdaExpressionWithOneParamater {

	public static void main(String[] args) {
		OneParameterInterface one = (int a) -> {
			System.out.println("Hi Mayank, Your Employee Id is : " + a);
		};
		one.printText(10);
	}

}
interface OneParameterInterface{
	public void printText(int a);
}
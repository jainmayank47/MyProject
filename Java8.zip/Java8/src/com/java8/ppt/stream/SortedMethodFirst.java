package com.java8.ppt.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class SortedMethodFirst {

	public static void main(String[] args) {
		List<Integer> numberList = new ArrayList<>();
		numberList.add(10);
		numberList.add(3);
		numberList.add(11);
		numberList.add(12);
		numberList.add(7);
		numberList.add(15);
		numberList.add(0);
		System.out.println("Before sorting : "+numberList);
		
		List<Integer> sortedList = numberList.stream().sorted().
				collect(Collectors.toList());
		System.out.println("after sorting : "+sortedList);

	}

}

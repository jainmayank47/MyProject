package com.java8.ppt.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import com.java8.ppt.functional.collection.Employee;

public class FirstProgramme {

	public static void main(String[] args) {
		Employee e = new Employee(101,"mayank");
		Employee e2 = new Employee(1001,"sunil");
		Employee e3 = new Employee(102,"abhishek");
		Employee e4 = new Employee(1002,"aman");
		Employee e5 = new Employee(103,"ashok");
		Employee e6 = new Employee(1003,"baman");
		List<Employee> empList= new ArrayList<>();
		empList.add(e6);
		empList.add(e5);
		empList.add(e4);
		empList.add(e3);
		empList.add(e2);
		empList.add(e);
		System.out.println(empList.toString());
		
		List<Employee> empList1 = empList.stream().filter((emp->emp.getEmpNo()>500)).collect(Collectors.toList());
		System.out.println(empList1);
		
		/*List<Employee> empList2 = empList.stream().map((emp->emp.getEmpNo()>500)).filter((emp->emp.getEmpNo()>500)).collect(Collectors.toList());
		System.out.println(empList2);*/

	}

}

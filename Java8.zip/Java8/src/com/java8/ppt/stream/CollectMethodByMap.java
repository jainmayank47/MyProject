package com.java8.ppt.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class CollectMethodByMap {

	public static void main(String[] args) {
		List<String> StudentNameList= new ArrayList<>();
		StudentNameList.add("mayank");
		StudentNameList.add("aman");
		StudentNameList.add("Rohit");
		StudentNameList.add("Sameer");
		StudentNameList.add("pawan");
		// collectMethod By Map
		List<String> studentList = StudentNameList.stream().map(s -> s.toUpperCase()).
				collect(Collectors.toList());
		System.out.println(studentList);
	}
}

package com.java8.ppt.stream;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.java8.ppt.functional.collection.Employee;

public class MapMethodExample {

	public static void main(String[] args) {

		//List<Employee> empList = new ArrayList<>();
		List<Employee> empList = new ArrayList<>();
		empList.add(new Employee(104, "Zakir"));
		empList.add(new Employee(101, "Naveen"));
		empList.add(new Employee(103, "Aamir"));
		empList.add(new Employee(102, "Viplove"));
		empList.add(new Employee(105, "Ritik"));
		Function<Employee,HashMap<String,Employee>> empFn = emp->{
			HashMap<String,Employee> empInfoMap = new HashMap<>();
		empInfoMap.put(emp.getEmpName(), emp);
		return empInfoMap;};
		/*List<HashMap<String,Employee>> empInfoMapList =empList.stream().map(emp->{
			HashMap<String,Employee> empInfoMap = new HashMap<>();
			empInfoMap.put(emp.getEmpName(), emp);
			return empInfoMap;
		}).collect(Collectors.toList());*/
		List<HashMap<String, Employee>> empInfoMapList = empList.stream().map(empFn).collect(Collectors.toList());
		System.out.println(empInfoMapList.toString());
	}
	
}

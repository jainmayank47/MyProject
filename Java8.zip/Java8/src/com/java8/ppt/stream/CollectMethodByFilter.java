package com.java8.ppt.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class CollectMethodByFilter {

	public static void main(String[] args) {
		List<String> StudentNameList= new ArrayList<>();
		StudentNameList.add("mayank");
		StudentNameList.add("aman");
		StudentNameList.add("Rohit");
		StudentNameList.add("Sameer");
		StudentNameList.add("pawan");
		// collectMethod By Filter
		List<String> studentList = StudentNameList.stream().filter(s -> s.length() > 5).
				collect(Collectors.toList());
		System.out.println(studentList);
	}
}

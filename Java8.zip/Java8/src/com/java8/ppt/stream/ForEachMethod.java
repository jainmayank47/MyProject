package com.java8.ppt.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.java8.ppt.functional.collection.Employee;

public class ForEachMethod {

	public static void main(String[] args) {
		List<Employee> empList = new ArrayList<>();
		empList.add(new Employee(104, "Zakir"));
		empList.add(new Employee(101, "Naveen"));
		empList.add(new Employee(103, "Aamir"));
		empList.add(new Employee(102, "Viplove"));
		empList.add(new Employee(105, "Ritik"));
		System.out.println("Before for each method : "+empList);
		empList.stream().forEach(e -> e.setEmpNo(e.getEmpNo() + 1000));
		System.out.println();
		System.out.println("after for each method : "+empList);

	}

}

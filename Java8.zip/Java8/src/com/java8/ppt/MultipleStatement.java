package com.java8.ppt;

public class MultipleStatement {

	public static void main(String[] args) {
		MultipleStatementInterface msi =()->{
			System.out.println("Hello mayank");
			System.out.println("How are you?");
			System.out.println("How's your life going on?");
		};
		msi.sayHello();
	}

}
interface MultipleStatementInterface{
	public void sayHello();
}
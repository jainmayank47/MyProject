package com.java8.ppt;

public class RemoveReturnKeyword {

	public static void main(String[] args) {
		RemoveReturnKeywordInterface i = (a,b)->a+b;
		System.out.println(i.addNumber(10, 20));

	}

}
interface RemoveReturnKeywordInterface{
	public int addNumber(int a,int b);
}
package com.java8.ppt.defaultmethods;

public interface ObjectClassMethods {

	default int hashCode(){
		return 10;
	}
}

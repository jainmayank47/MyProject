package com.java8.ppt.defaultmethods;

public class DefaultMethodAvailable implements DefaultMethodInterface {

	public static void main(String[] args) {
		DefaultMethodAvailable dma = new DefaultMethodAvailable();
		dma.displayInterfaceName();
	}
}

interface DefaultMethodInterface{
	default void displayInterfaceName(){
		System.out.println("displayInterfaceName");
	}
}
package com.java8.ppt.defaultmethods;

public class CompileTimeError implements Left,Right {

	public static void main(String[] args) {
		/*CompileTimeError c = new CompileTimeError();
		c.showUserName();*/
	}

	/*public void showUserName() {
		Right.super.showUserName();
	}*/

}
interface Left{
	default void showUserName(){
		System.out.println("Mayank Jain");
	}
}
interface Right{
	default void showUserName(){
		System.out.println("Gagan Pandya");
	}
}
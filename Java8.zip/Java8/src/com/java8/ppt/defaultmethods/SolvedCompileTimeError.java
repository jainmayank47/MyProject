package com.java8.ppt.defaultmethods;

public class SolvedCompileTimeError implements Left1,Right1 {

	public static void main(String[] args) {
		SolvedCompileTimeError s=new SolvedCompileTimeError();
		s.showUserName();

	}
	@Override
	public void showUserName() {
		System.out.println("Atishay Sharma");
		//Right1.super.showUserName();
	}

}
interface Left1{
	default void showUserName(){
		System.out.println("Mayank Jain");
	}
}
interface Right1{
	default void showUserName(){
		System.out.println("Gagan Pandya");
	}
}
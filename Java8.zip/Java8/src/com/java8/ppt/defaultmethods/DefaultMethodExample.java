package com.java8.ppt.defaultmethods;

public interface DefaultMethodExample {

	public void saveUserInfo();
	
	public String getUserName();
	
	default String getUserCountryName(){
		return "India";
	}
}

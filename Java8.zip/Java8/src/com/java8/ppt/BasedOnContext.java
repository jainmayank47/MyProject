package com.java8.ppt;

public class BasedOnContext {

	public static void main(String[] args) {
		BasedOnContextInterface i = (a,b)->{return a+b;};
		System.out.println(i.addNumber(10, 20));
	}

}
interface BasedOnContextInterface{
	public int addNumber(int a,int b);
}
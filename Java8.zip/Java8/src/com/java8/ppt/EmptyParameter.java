package com.java8.ppt;

public class EmptyParameter {

	public static void main(String[] args) {
		EmptyParameterInterface epi=()->System.out.println("Hello World");
		epi.printHello();
	}

}
interface EmptyParameterInterface{
	public void printHello();
}
package com.java8.ppt.predicate;

public class User {

	public String userName;
	public String password;
	
	public User(String userName, String password) {
		this.userName = userName;
		this.password = password;
	}
}

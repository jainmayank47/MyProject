package com.java8.ppt.predicate;

import java.util.function.Predicate;

public class UserCredentialPredicate {

	public static void main(String[] args) {
		User user = new User("Mayank", "12345678G");
		User user1 = new User("Aman", "12345678G");
		Predicate<User> userPredicate = u->u.userName.equals("Mayank")&& u.password.equals("12345678G");
		checkUserCredentials(userPredicate,user); // valid user...
		System.out.println("=====================================");
		checkUserCredentials(userPredicate,user1); // username and password incorrect.
	}

	public static void checkUserCredentials(Predicate<User> userPredicate, User user) {
		if(userPredicate.test(user)){
			System.out.println("Valid user,you can get all services.");
		}else{
			System.out.println("username and password incorrect.");
		}
	}
}

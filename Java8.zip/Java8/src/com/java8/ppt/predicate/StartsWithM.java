package com.java8.ppt.predicate;

import java.util.function.Predicate;

public class StartsWithM {

	public static void main(String[] args) {
		Predicate<String> startWithPredicate = s->s.charAt(0)=='M';
		System.out.println(startWithPredicate.test("Aamir")); // false
		System.out.println("==========================");
		System.out.println(startWithPredicate.test("Mayank")); // true

	}
}

package com.java8.ppt.staticmethods;

public class StaticMethodExample implements TestInterface {

	public static void main(String[] args) {
		String empOrgName = TestInterface.getEmpOrgName();
		System.out.println(empOrgName);
	}
}
interface TestInterface{
	static String getEmpOrgName(){
		return "Galaxy Weblinks Ltd.";
	}
}
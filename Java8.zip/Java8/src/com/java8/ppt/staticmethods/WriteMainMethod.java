package com.java8.ppt.staticmethods;

public interface WriteMainMethod {

	public static void main(String[] args) {
		System.out.println("mayank jain");
	}
}

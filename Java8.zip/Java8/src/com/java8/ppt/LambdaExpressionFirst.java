package com.java8.ppt;

public class LambdaExpressionFirst {

	public void printText(){
		System.out.println("Hello World");
	}
}

package com.java8.ppt.function;

import java.util.function.Function;

public class CheckStringLength {

	public static void main(String[] args) {
		Function<String, Integer> function = s->s.length();
		System.out.println(function.apply("Galaxy")); // print 6
		System.out.println(function.apply("Galaxy weblinks")); // print 15
	}
}

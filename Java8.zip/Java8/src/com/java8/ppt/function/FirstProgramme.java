package com.java8.ppt.function;

public class FirstProgramme {

}

interface Function<T, R> {
	public R apply(T t);
}
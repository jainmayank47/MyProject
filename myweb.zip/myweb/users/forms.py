from django import forms
from users.models import Employee

class UserRegistrationForm(forms.ModelForm):
    class Meta:
        model=Employee
        fields="__all__"

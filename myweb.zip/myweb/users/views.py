from django.shortcuts import render,redirect
from users.forms import UserRegistrationForm
from users.models import Employee
from django.http import HttpResponse

def index(request):
    return render(request,"templatesApp/index.html")

def employeeData(request):
    employeeData=Employee.objects.all()
    return render(request,"templatesApp/employeeData.html",{'employees':employeeData})

def AddEmployeeData(request):
    form = UserRegistrationForm()
    print("mayank jain")
    if request.method=='POST':
        print("POST method")
        form = UserRegistrationForm(request.POST)
        print("1111111111111111111111111")
        if form.is_valid():
            print("2222222222222222222")
            form.save()
            print("save successfully....")
            return redirect("/")
    return render(request,"templatesApp/addEmployee.html",{'form':form})


def DeleteEmployee(request,id):
    employee=Employee.objects.get(id=id)
    employee.delete()
    return redirect("/")


def UpdateEmployeeData(request,id):
    employee=Employee.objects.get(id=id)
    form = UserRegistrationForm(instance=employee)
    if request.method=='POST':
        form = UserRegistrationForm(request.POST,instance=employee)
        if form.is_valid():
            form.save()
            return redirect("/")
    return render(request,"templatesApp/updateEmployee.html",{'form':form})

def AddEmployeeData(request):
    form = UserRegistrationForm()
    print("mayank jain")
    if request.method=='POST':
        print("POST method")
        form = UserRegistrationForm(request.POST)
        print("1111111111111111111111111")
        if form.is_valid():
            print("2222222222222222222")
            form.save()
            print("save successfully....")
            return redirect("/")
    return render(request,"templatesApp/addEmployee.html",{'form':form})


"""
def UserRegistrationView(request):
    form = forms.UserRegistrationForm()
    if request.method=='POST':
        form = forms.UserRegistrationForm(request.POST)
        if form.is_valid():
            print("form is valid")
            print("firstName: ",form.cleaned_data['firstName'])
            print("lastName: ",form.cleaned_data['lastName'])
            print("email: ",form.cleaned_data['email'])
            print("mobile no: ",form.cleaned_data['mobileNo'])
    return render(request,"templatesApp/userRegistration.html",{"forms":form})

"""

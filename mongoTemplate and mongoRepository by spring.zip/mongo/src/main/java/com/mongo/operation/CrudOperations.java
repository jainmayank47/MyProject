package com.mongo.operation;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

public class CrudOperations {

	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(SpringMongoConfig.class);
	    MongoOperations mongoOperation = (MongoOperations)ctx.getBean("mongoTemplate");
	  
	    Query query = new Query();
	    query.addCriteria(Criteria.where("id").is("5c9e85c87c070a130063084d"));
	    EmployeeInfo e =  mongoOperation.findOne(query,EmployeeInfo.class, "users");
	    System.out.println(e.toString());
	    Update update = new Update();
	    update.set("empName", "ramesh");
	    update.set("mobileNo", "654123");
	     mongoOperation.updateFirst(query,update,EmployeeInfo.class, "users");
	     e =  mongoOperation.findOne(query,EmployeeInfo.class, "users");
	    System.out.println("Updated : "+e.toString());
	    
	    // getAll(mongoOperation); 
		   // saveRecords(mongoOperation);
		  //  findOneRecord(mongoOperation);
	}

	private static void findOneRecord(MongoOperations mongoOperation) {
		Query query = new Query();
	    query.addCriteria(Criteria.where("id").is("5c9e85c87c070a130063084d"));
	    EmployeeInfo e =  mongoOperation.findOne(query,EmployeeInfo.class, "users");
	    System.out.println(e.toString());
	}

	private static void getAll(MongoOperations mongoOperation) {
		List<EmployeeInfo> eList = mongoOperation.findAll(EmployeeInfo.class,"users");
	    for (EmployeeInfo e1 :eList){
	    	System.out.println(e1.toString());
	    }
	}

	private static void saveRecords(MongoOperations mongoOperation) {
		EmployeeInfo e = new EmployeeInfo("mayank", "11123456");
	    mongoOperation.save(e);
	    System.out.println("1111111111111111111");
	}

}

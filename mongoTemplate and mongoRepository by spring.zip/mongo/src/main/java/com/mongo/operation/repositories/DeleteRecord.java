package com.mongo.operation.repositories;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class DeleteRecord {

	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		 EmployeeInfoService emp = (EmployeeInfoService)ctx.getBean("empService");
		 emp.getEmpRepo().delete("5cb4d0ae22d98e365ea40017");
		 System.out.println("record deleted successfully..!");
	}
}

package com.mongo.operation;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="users")
public class EmployeeInfo {

	@Id
	private String id;
	private String empName;
	private String mobileNo;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public EmployeeInfo(String empName, String mobileNo) {
		super();
		this.empName = empName;
		this.mobileNo = mobileNo;
	}
	@Override
	public String toString() {
		return "EmployeeInfo [id=" + id + ", empName=" + empName + ", mobileNo=" + mobileNo + "]";
	}
	
	
}

package com.mongo.operation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

public class DeleteOperation {

	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(SpringMongoConfig.class);
	    MongoOperations mongoOperation = (MongoOperations)ctx.getBean("mongoTemplate");
	    Query query = new Query();
	    query.addCriteria(Criteria.where("id").is("5cb37ae522d9070ac6cd3350"));
	    mongoOperation.remove(query,EmployeeInfo.class, "users");
	    System.out.println("record deleted successfully..!");

	}

}

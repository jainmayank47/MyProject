package com.mongo.operation.repositories;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("empService")
public class EmployeeInfoServiceImpl implements EmployeeInfoService {

	@Autowired
	EmployeeRepository employeeRepository;

	public EmployeeRepository getEmpRepo() {
		return employeeRepository;
	}
}

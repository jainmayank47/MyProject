package com.mongo.operation.repositories;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

@Configuration
@ComponentScan(basePackages={"com.mongo.operation.repositories"})
@EnableMongoRepositories(basePackages={"com.mongo.operation.repositories"})
public class AppConfig {

	@Bean
	 public MongoDbFactory mongoDbFactory() throws Exception {
		 MongoClientURI uri = new MongoClientURI("mongodb://admin:admin@cluster0-shard-00-00-24mjc.mongodb.net:27017,cluster0-shard-00-01-24mjc.mongodb.net:27017,cluster0-shard-00-02-24mjc.mongodb.net:27017/test?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true");

		return new SimpleMongoDbFactory(new MongoClient(uri), "test");
	}

	@Bean
	public MongoTemplate mongoTemplate() throws Exception {
		
		MongoTemplate mongoTemplate = new MongoTemplate(mongoDbFactory());
		return mongoTemplate;
		
	}
}

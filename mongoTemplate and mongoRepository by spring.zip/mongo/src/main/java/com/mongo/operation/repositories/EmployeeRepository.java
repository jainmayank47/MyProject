package com.mongo.operation.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.mongo.operation.EmployeeInfo;

public interface EmployeeRepository extends MongoRepository<EmployeeInfo, String>{

	@Query("{ 'empName': ?0, 'mobileNo': ?1}")
	public EmployeeInfo findByEmployeeNameAndMobileNo(String empName, String mobileNo);
}

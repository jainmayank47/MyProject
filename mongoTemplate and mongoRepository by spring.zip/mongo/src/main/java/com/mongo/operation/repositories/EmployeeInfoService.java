package com.mongo.operation.repositories;

public interface EmployeeInfoService {

	EmployeeRepository getEmpRepo();
}

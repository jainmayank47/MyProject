package com.mongo.operation.repositories;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.stereotype.Component;

import com.mongo.operation.EmployeeInfo;
import com.mongo.operation.SpringMongoConfig;

public class Save {
	
	public static void main(String[] args) {
		 EmployeeInfo e = new EmployeeInfo("mayank", "11123456");
		 ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		 EmployeeInfoService emp = (EmployeeInfoService)ctx.getBean("empService");
		 emp.getEmpRepo().save(e);
		 System.out.println("1111111111111111111");
	}
	
}

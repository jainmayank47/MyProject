package com.mongo.operation.repositories;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mongo.operation.EmployeeInfo;

public class FindAll {

	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		EmployeeInfoService emp = (EmployeeInfoService) ctx.getBean("empService");
		List<EmployeeInfo> empList = emp.getEmpRepo().findAll();
		for (EmployeeInfo e1 : empList) {
			System.out.println(e1.toString());
		}
	}

}

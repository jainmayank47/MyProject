package com.mongo.operation.repositories;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mongo.operation.EmployeeInfo;

public class FindOne {

	public static void main(String[] args) {
		 ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		 EmployeeInfoService emp = (EmployeeInfoService)ctx.getBean("empService");
		EmployeeInfo e = emp.getEmpRepo().findOne("5c9e85c87c070a130063084d");
		System.out.println(e.toString());

	}

}
